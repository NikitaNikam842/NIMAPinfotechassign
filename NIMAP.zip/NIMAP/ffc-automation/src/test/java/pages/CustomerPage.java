package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CustomerPage {
    WebDriver driver;
    public CustomerPage(WebDriver driver) {
        this.driver = driver;
    }

    By customerMenu = By.xpath("//span[text()='Customers']");
    By addCustomerBtn = By.xpath("//button[contains(text(),'Add Customer')]");
    By nameField = By.name("name");
    By emailField = By.name("email");
    By submitBtn = By.xpath("//button[contains(text(),'Submit')]");
    By toast = By.className("Toastify__toast-body");

    public void addCustomer(String name, String email) {
        driver.findElement(customerMenu).click();
        driver.findElement(addCustomerBtn).click();
        driver.findElement(nameField).sendKeys(name);
        driver.findElement(emailField).sendKeys(email);
        driver.findElement(submitBtn).click();
    }

    public String getToastMessage() {
        return driver.findElement(toast).getText();
    }
}
