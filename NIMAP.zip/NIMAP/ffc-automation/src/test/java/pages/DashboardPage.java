package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DashboardPage {
    WebDriver driver;
    public DashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    By punchInBtn = By.xpath("//button[contains(text(),'Punch In')]");
    By toast = By.className("Toastify__toast-body");

    public void clickPunchIn() {
        driver.findElement(punchInBtn).click();
    }

    public String getToastMessage() {
        WebElement toastMsg = driver.findElement(toast);
        return toastMsg.getText();
    }
}
