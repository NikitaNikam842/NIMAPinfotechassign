package utils;

public class TestData {
    public static String email = "nrnikam121@gmail.com";
    public static String password = "Nikita@123";
    public static String customerName = "Test Customer";
    public static String customerEmail = "nrnikam121@gmail.com";
}
