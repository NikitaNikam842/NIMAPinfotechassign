package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.DashboardPage;
import pages.LoginPage;
import utils.BaseTest;
import utils.TestData;

public class PunchInTest extends BaseTest {

    @Test
    public void testPunchInToast() throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(TestData.email, TestData.password);

        Thread.sleep(2000);
        DashboardPage dash = new DashboardPage(driver);
        dash.clickPunchIn();
        Thread.sleep(1000);

        String toastMsg = dash.getToastMessage();
        Assert.assertTrue(toastMsg.contains("successfully") || toastMsg.contains("already"), "Toast not found");
    }
}