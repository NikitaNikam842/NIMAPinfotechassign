package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CustomerPage;
import pages.LoginPage;
import utils.BaseTest;
import utils.TestData;

public class CustomerTest extends BaseTest {

    @Test
    public void testAddCustomer() throws InterruptedException {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(TestData.email, TestData.password);
        Thread.sleep(2000);

        CustomerPage customerPage = new CustomerPage(driver);
        customerPage.addCustomer(TestData.customerName, TestData.customerEmail);
        Thread.sleep(1000);

        String toastMsg = customerPage.getToastMessage();
        Assert.assertTrue(toastMsg.contains("successfully"), "Add customer toast not found");
    }
}