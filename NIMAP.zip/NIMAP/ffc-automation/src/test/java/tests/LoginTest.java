package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import utils.BaseTest;
import utils.TestData;

public class LoginTest extends BaseTest {

    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(TestData.email, TestData.password);
        Assert.assertTrue(driver.getCurrentUrl().contains("dashboard"), "Login failed");
    }
}